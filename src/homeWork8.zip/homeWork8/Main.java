package homeWork8;
/*
1. Реализовать то же самое, что было на занятии(графический интерфейс)
 */
public class Main {
    public static void main(String[] args) {
        MyWindow window = new MyWindow();
        window.initWindow();
    }
}
