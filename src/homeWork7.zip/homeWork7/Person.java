package homeWork7;
/*
public class Person {
    public void addFood(Plate plate, int food) {
        System.out.println("Хозяин добавляет еды в тарелку");
        plate.increaseFood(food);
    }
}
*/